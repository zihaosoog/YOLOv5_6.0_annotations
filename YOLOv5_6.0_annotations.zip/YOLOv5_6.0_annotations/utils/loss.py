# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
Loss functions
"""

import torch
import torch.nn as nn

from utils.metrics import bbox_iou
from utils.torch_utils import is_parallel


def smooth_BCE(eps=0.1):  # https://github.com/ultralytics/yolov3/issues/238#issuecomment-598028441
    # return positive, negative label smoothing BCE targets
    return 1.0 - 0.5 * eps, 0.5 * eps


class BCEBlurWithLogitsLoss(nn.Module):
    # BCEwithLogitLoss() with reduced missing label effects.
    def __init__(self, alpha=0.05):
        super().__init__()
        self.loss_fcn = nn.BCEWithLogitsLoss(reduction='none')  # must be nn.BCEWithLogitsLoss()
        self.alpha = alpha

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true)
        pred = torch.sigmoid(pred)  # prob from logits
        dx = pred - true  # reduce only missing label effects
        # dx = (pred - true).abs()  # reduce missing label and false label effects
        alpha_factor = 1 - torch.exp((dx - 1) / (self.alpha + 1e-4))
        loss *= alpha_factor
        return loss.mean()


class FocalLoss(nn.Module):
    # Wraps focal loss around existing loss_fcn(), i.e. criteria = FocalLoss(nn.BCEWithLogitsLoss(), gamma=1.5)
    def __init__(self, loss_fcn, gamma=1.5, alpha=0.25):
        super().__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'  # required to apply FL to each element

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true) #! BCEloss: -log(p_t)
        #! 多标签分类中采用alpha和gamma平衡正负样本不均衡
        # p_t = torch.exp(-loss)
        # loss *= self.alpha * (1.000001 - p_t) ** self.gamma  # non-zero power for gradient stability

        # TF implementation https://github.com/tensorflow/addons/blob/v0.7.1/tensorflow_addons/losses/focal_loss.py
        #! BCEloss+sigmoid
        pred_prob = torch.sigmoid(pred)  # prob from logits
        #! 如下可表示分段函数true为0/1两种取值的两种结果
        p_t = true * pred_prob + (1 - true) * (1 - pred_prob)
        alpha_factor = true * self.alpha + (1 - true) * (1 - self.alpha)
        modulating_factor = (1.0 - p_t) ** self.gamma
        #! loss = alpha_factor * modulating_factor * BCEloss
        loss *= alpha_factor * modulating_factor

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss


class QFocalLoss(nn.Module):
    # Wraps Quality focal loss around existing loss_fcn(), i.e. criteria = FocalLoss(nn.BCEWithLogitsLoss(), gamma=1.5)
    def __init__(self, loss_fcn, gamma=1.5, alpha=0.25):
        super().__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'  # required to apply FL to each element

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true)

        pred_prob = torch.sigmoid(pred)  # prob from logits
        alpha_factor = true * self.alpha + (1 - true) * (1 - self.alpha)
        modulating_factor = torch.abs(true - pred_prob) ** self.gamma
        loss *= alpha_factor * modulating_factor

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss


class ComputeLoss:
    # Compute losses
    def __init__(self, model, autobalance=False):
        self.sort_obj_iou = False   #!后面筛选置信度损失正样本的时候是否先对iou排序
        device = next(model.parameters()).device  # get model device
        h = model.hyp  # hyperparameters

        # Define criteria
        #! h['cls_pw']=1，正样本(pw)权重为1
        BCEcls = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([h['cls_pw']], device=device))
        BCEobj = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([h['obj_pw']], device=device))

        # Class label smoothing https://arxiv.org/pdf/1902.04103.pdf eqn 3
        #! 标签平滑，eps=0不平滑返回0或1，否则采用标签平滑
        self.cp, self.cn = smooth_BCE(eps=h.get('label_smoothing', 0.0))  # positive, negative BCE targets

        # Focal loss
        g = h['fl_gamma']  # focal loss gamma
        if g > 0:
            BCEcls, BCEobj = FocalLoss(BCEcls, g), FocalLoss(BCEobj, g)

        det = model.module.model[-1] if is_parallel(model) else model.model[-1]  # Detect() module
        #! nl：num det layers,若为3层返回3个系数，平衡3个尺度的特征图置信度损失即objloss，否则返回nl个系数
        self.balance = {3: [4.0, 1.0, 0.4]}.get(det.nl, [4.0, 1.0, 0.25, 0.06, 0.02])  # P3-P7
        #! list(det.stride).index(16)找出下采样步长[8,16,32]中值为16的索引，自动更新上面的objloss平衡系数
        self.ssi = list(det.stride).index(16) if autobalance else 0  # stride 16 index
        #! classloss,objloss,计算真实框的置信度标准的iou ratio,超参数,是否自动更新objloss平衡系数
        self.BCEcls, self.BCEobj, self.gr, self.hyp, self.autobalance = BCEcls, BCEobj, 1.0, h, autobalance
        for k in 'na', 'nc', 'nl', 'anchors':
            #! 将det的k属性赋值给self.k属性
            setattr(self, k, getattr(det, k))

    def __call__(self, p, targets):  # predictions, targets, model
        """
        p网络预测输出,p[i].shape = (b, 3, h, w, x+y+h+w+obj+nc)/
        batch中第b张图,第a个anchor idx,feature map 长宽为h和w,预测的框中心坐标据网格的偏移量x和y/
        利用网格gridxy计算预测框xyhw
        """
        device = targets.device #! 确定运行设备
        #! 初始化类别，回归以及置信度损失
        lcls, lbox, lobj = torch.zeros(1, device=device), torch.zeros(1, device=device), torch.zeros(1, device=device)
        #! 各尺度特征对应的3种anchor筛选的targets即GT
        tcls, tbox, indices, anchors = self.build_targets(p, targets)  # targets

        # Losses
        for i, pi in enumerate(p):  # layer index, layer predictions
            b, a, gj, gi = indices[i]  # image, anchor, gridy, gridx
            tobj = torch.zeros_like(pi[..., 0], device=device)  # target obj

            n = b.shape[0]  # number of targets
            if n:
                #! 精确得到第b张图片的第a个feature map的grid_cell(gi, gj)对应的预测值
                #! 用这个预测值与我们筛选的这个grid_cell的真实框进行预测(计算损失)
                ps = pi[b, a, gj, gi]  # prediction subset corresponding to targets

                # Regression
                pxy = ps[:, :2].sigmoid() * 2 - 0.5
                pwh = (ps[:, 2:4].sigmoid() * 2) ** 2 * anchors[i]
                #! xy的预测范围为-0.5~1.5,因为除了自身格子外，还有可能还有相邻的两个格子
                # wh的预测范围是0~4 ,是由于shape的过滤规则,wh预测输出也不再是任意范围
                pbox = torch.cat((pxy, pwh), 1)  # predicted box
                #todo
                iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, CIoU=True)  # iou(prediction, target)
                lbox += (1.0 - iou).mean()  # iou loss

                # Objectness
                #! iou.detach()不需要更新梯度
                score_iou = iou.detach().clamp(0).type(tobj.dtype)
                if self.sort_obj_iou:
                    #! argsort从小到大排序，返回排序后元素的idx
                    sort_id = torch.argsort(score_iou)
                    #todo issue
                    b, a, gj, gi, score_iou = b[sort_id], a[sort_id], gj[sort_id], gi[sort_id], score_iou[sort_id]
                #! 预测向量中有obj置信度，但GT没有，所以人为设定GT的置信度
                tobj[b, a, gj, gi] = (1.0 - self.gr) + self.gr * score_iou  # iou ratio

                # Classification
                if self.nc > 1:  # cls loss (only if multiple classes)
                    #! 维度与ps[:,5:]相同，全部填充为cn(negtive)，全部初始化为负样本
                    t = torch.full_like(ps[:, 5:], self.cn, device=device)  # targets
                    #! tcls[i]对应填充cp(postive)，填充正样本
                    t[range(n), tcls[i]] = self.cp
                    #! 计算clsloss
                    lcls += self.BCEcls(ps[:, 5:], t)  # BCE

                # Append targets to text file
                # with open('targets.txt', 'a') as file:
                #     [file.write('%11.5g ' * 4 % tuple(x) + '\n') for x in torch.cat((txy[i], twh[i]), 1)]
            #! 计算objloss，正负样本都计算
            obji = self.BCEobj(pi[..., 4], tobj)
            #! 平衡各层输出特征的objloss
            lobj += obji * self.balance[i]  # obj loss
            if self.autobalance:
                self.balance[i] = self.balance[i] * 0.9999 + 0.0001 / obji.detach().item()

        if self.autobalance:
            self.balance = [x / self.balance[self.ssi] for x in self.balance]
        lbox *= self.hyp['box']
        lobj *= self.hyp['obj']
        lcls *= self.hyp['cls']
        bs = tobj.shape[0]  # batch size

        #! .detach()  利用损失值进行反向传播 利用梯度信息更新的是损失函数的参数 而对于损失这个值是不需要梯度反向传播的
        return (lbox + lobj + lcls) * bs, torch.cat((lbox, lobj, lcls)).detach()

    def build_targets(self, p, targets):
        # Build targets for compute_loss(), input targets(image_idx,class,x,y,w,h)
        na, nt = self.na, targets.shape[0]  # number of anchors, targets
        tcls, tbox, indices, anch = [], [], [], []
        #! 7: image_index+class+xywh+anchor_index
        gain = torch.ones(7, device=targets.device)  # normalized to gridspace gain
        #! ai:[na,nt]，na行，每行元素表示各target所属的(对应的)anchor_idx
        ai = torch.arange(na, device=targets.device).float().view(na, 1).repeat(1, nt)  # same as .repeat_interleave(nt)
        #! 复制na份targets，包括(image_idx,class,x,y,w,h)并cat包含ai中的anchor_idx
        targets = torch.cat((targets.repeat(na, 1, 1), ai[:, :, None]), 2)  # append anchor indices

        #! 当GT同时被多个相邻网格匹配到，则计算GT中心与网格距离远近，采用上下左右中5个格子计算offset
        g = 0.5  # bias
        off = torch.tensor([[0, 0],
                            [1, 0], [0, 1], [-1, 0], [0, -1],  # j,k,l,m
                            # [1, 1], [1, -1], [-1, 1], [-1, -1],  # jk,jm,lk,lm
                            ], device=targets.device).float() * g  # offsets

        for i in range(self.nl):#! nl层detect即nl个特征尺度
            #! self.anchors[3,3,2]3个尺度，每个尺度3个anchors，每个anchor两个量即长宽
            anchors = self.anchors[i] #! 取第i个尺度的anchors
            #! p:[batch_size,num_anch,grid_h(feature_size_h),grid_w,xywh+num_class+边框置信度]
            #! 边框置信度：衡量边框内是正还是负样本
            #! gain: 保存每个输出feature map的宽高 -> gain[2:6]=gain[whwh]
            gain[2:6] = torch.tensor(p[i].shape)[[3, 2, 3, 2]]  # xyxy gain

            # Match targets to anchors
            #! 将target中归一化的坐标大小映射到gain中保存的特征图大小中
            t = targets * gain
            
            if nt:
                # Matches
                #! 第i个特征尺度的各anchor对应的正样本w和h与其anchor的w和h分别比率（w/w，h/h）
                r = t[:, :, 4:6] / anchors[:, None]  # wh ratio
                #! 长比率和宽比率中max是否小于阈值，小于则正样本，否则负样本
                j = torch.max(r, 1 / r).max(2)[0] < self.hyp['anchor_t']  # compare
                #! yolov3 v4的筛选方法: wh_iou  GT与anchor的wh_iou超过一定的阈值就是正样本
                # j = wh_iou(anchors, t[:, 4:6]) > model.hyp['iou_t']  # iou(3,n)=wh_iou(anchors(3,2), gwh(n,2))
                #! 去掉false项即负样本保留正样本
                t = t[j]  # filter

                # Offsets
                gxy = t[:, 2:4]  #! grid xy GT的坐标与特征图左上角
                gxi = gain[[2, 3]] - gxy  #! inverse 与右下角的偏移即坐标
                #! gxy % 1:gxy中心坐标为小数，方格坐标为整数，对1取余即该点坐标与所在方格边距
                # 筛选中心坐标 距离当前grid_cell的左、上方偏移小于g=0.5 且 中心坐标必须大于1(坐标不能在边上 此时就没有4个格子了)
                # j: bool 如果是True表示当前target中心点所在的格子的左边格子也对该target进行回归(后续进行计算损失)
                # k: bool 如果是True表示当前target中心点所在的格子的上边格子也对该target进行回归(后续进行计算损失)
                j, k = ((gxy % 1 < g) & (gxy > 1)).T
                # 筛选中心坐标 距离当前grid_cell的右、下方偏移小于g=0.5 且 中心坐标必须大于1(坐标不能在边上 此时就没有4个格子了)
                # l: bool 如果是True表示当前target中心点所在的格子的右边格子也对该target进行回归(后续进行计算损失)
                # m: bool 如果是True表示当前target中心点所在的格子的下边格子也对该target进行回归(后续进行计算损失)
                l, m = ((gxi % 1 < g) & (gxi > 1)).T
                # j: torch.ones_like(j): 当前格子, 不需要筛选全是True
                #! j, k, l, m: 左上右下格子的筛选结果
                j = torch.stack((torch.ones_like(j), j, k, l, m))
                #! 5个格子筛选得到的
                t = t.repeat((5, 1, 1))[j]
                #! 筛选出的网格与其中心网格的边界的bias（上下左右中网格）
                #! shape(1, ?, 2) + shape(5, 1, 2) = shape(5, ?, 2)
                offsets = (torch.zeros_like(gxy)[None] + off[:, None])[j]
            else:
                t = targets[0]
                offsets = 0

            # Define
            b, c = t[:, :2].long().T  # image, class
            gxy = t[:, 2:4]  # grid xy
            gwh = t[:, 4:6]  # grid wh
            #! 计算GT相对3个网格的坐标,long取整即为方格的坐标
            gij = (gxy - offsets).long()
            '''
            比如有个目标的中心点x坐标为3.4,那么 3.4-0.5并向下取整,就为2了,那么就采用左边的格子了
            '''
            #! 拆解为横纵坐标
            gi, gj = gij.T  # grid xy indices

            # Append
            #! anchor idx
            a = t[:, 6].long()  # anchor indices
            #! indices:List(tuple*3)  tuple:(b,a,竖直方向第y个格子,竖直方向第x个格子)
            #! gj.clamp_(0, gain[3] - 1) 在(0,h)范围内的坐标，即在特征图大小尺寸内的坐标
            indices.append((b, a, gj.clamp_(0, gain[3] - 1), gi.clamp_(0, gain[2] - 1)))  # image, anchor, grid indices
            #! gxy - gij即偏移量offset
            tbox.append(torch.cat((gxy - gij, gwh), 1))  # box
            anch.append(anchors[a])  # anchors
            tcls.append(c)  # class

        return tcls, tbox, indices, anch
